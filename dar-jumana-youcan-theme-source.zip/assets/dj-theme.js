/* Presentation only: no checkout, catalogue writes, prices or analytics. */
(() => {
  const openers = new Map();
  document.querySelectorAll('[data-dj-open]').forEach(button => {
    button.addEventListener('click', () => {
      const dialog = document.getElementById(button.dataset.djOpen);
      if (!dialog || dialog.open) return;
      openers.set(dialog, button);
      dialog.showModal();
      button.setAttribute('aria-expanded', 'true');
    });
  });
  document.querySelectorAll('dialog.dj-menu-dialog,dialog.dj-search-dialog').forEach(dialog => {
    dialog.querySelectorAll('[data-dj-close]').forEach(button => button.addEventListener('click', () => dialog.close()));
    dialog.addEventListener('click', event => { if (event.target === dialog) {
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
    }});
    dialog.addEventListener('close', () => {
      const opener = openers.get(dialog);
      if (opener) { opener.setAttribute('aria-expanded', 'false'); opener.focus(); }
    });
  });
  document.addEventListener('click', event => {
    const parent = event.target.closest('.dj-desktop-nav .dj-submenu');
    document.querySelectorAll('.dj-desktop-nav .dj-submenu[open]').forEach(menu => {
      if (menu !== parent) menu.removeAttribute('open');
    });
  });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('.dj-desktop-nav .dj-submenu[open]').forEach(menu => {
      menu.removeAttribute('open'); menu.querySelector('summary').focus();
    });
  });
})();

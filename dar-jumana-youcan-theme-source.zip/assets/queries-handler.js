const paginateBtnPrev = document.querySelector('.paginate-btn-prev');
const paginateBtnNext = document.querySelector('.paginate-btn-next');
const paginateBtnCurrent = document.querySelectorAll('.paginate-btn');
const searchTitle = document.querySelector('#search-title');
const urlParams = new URLSearchParams(window.location.search);
const query = urlParams.get('q');
const sortField = urlParams.get('sort_field');
const sortOrder = urlParams.get('sort_order');
const sortSelect = document.querySelector('.sort-select');
const pagination = document.querySelector('.yc-pagination-wrapper');
const pageParam = pagination?.dataset.param || 'page[cod]';
const lastPage = Number(pagination?.dataset.last) || Infinity;
let page = +urlParams.get(pageParam);

const updateUrl = (key, value, url) => {
  if (url.searchParams.has(key)) {
    url.searchParams.set(key, value);
  } else {
    url.searchParams.append(key, value);
  }
};

const convertUrl = (key, value) => {
  const url = new URL(window.location.href);

  updateUrl(key, value, url);

  return url;
};

const convertUrlWithMultipleQuery = (keys, values) => {
  const url = new URL(window.location.href);

  keys.forEach((key, i) => updateUrl(key, values[i], url));

  return url;
};

if (page <= 1 || !page) {
  page = 1;
}

if (paginateBtnPrev && page > 1) {
  paginateBtnPrev.setAttribute('href', convertUrl(pageParam, page - 1));
}

if (paginateBtnNext && page < lastPage) {
  paginateBtnNext.setAttribute('href', convertUrl(pageParam, page + 1));
}

if (paginateBtnCurrent) {
  paginateBtnCurrent.forEach((btn) => btn.setAttribute('href', convertUrl(pageParam, btn.dataset.index)));
}

if (searchTitle) {
  if (query) searchTitle.textContent = `نتائج البحث عن: ${query}`;
}
// dropdown select
function setupDropdown(dropdownContent, convertUrlWithMultipleQuery) {
  // Handle the click event for the options in the dropdown
  dropdownContent.addEventListener('click', (event) => {
    event.preventDefault();
    const link = event.target.closest('a[data-value]');
    if (!link || !dropdownContent.contains(link)) return;
    const [newSortField, newSortOrder] = link.dataset.value.split('-');
    const nextUrl = convertUrlWithMultipleQuery(['sort_field', 'sort_order'], [newSortField, newSortOrder]);
    nextUrl.searchParams.delete(pageParam);
    window.location.href = nextUrl;
  });
}

function filterProduct() {
  const productFiltring = document.querySelector('#productDropdownFiltring');
  const filterDropdownBtn = productFiltring?.querySelector('.dropbtn');
  const filterDropdownContent = productFiltring?.querySelector('.dropdown-content');

  if (productFiltring) {
    const sortField = urlParams.get('sort_field') || 'price';
    const sortOrder = urlParams.get('sort_order') || 'asc';

    // Get the selected option from the URL parameters
    const sortOptions = [...filterDropdownContent.querySelectorAll('a[data-value]')];
    // Compare data values directly: query parameters are not CSS selectors.
    const selectedOption = sortOptions.find(option => option.dataset.value === `${sortField}-${sortOrder}`) || sortOptions[0];
    if (!selectedOption) return;
    sortOptions.forEach(option => {
      const [field, order] = option.dataset.value.split('-');
      const url = convertUrlWithMultipleQuery(['sort_field', 'sort_order'], [field, order]);
      url.searchParams.delete(pageParam);
      option.href = url.href;
      option.setAttribute('aria-current', String(option === selectedOption));
    });

    // Update the dropdown button text with the selected option
    const label = document.createElement('span');
    label.className = 'order-by';
    label.textContent = `${order_by} : ${selectedOption.textContent}`;
    filterDropdownBtn.replaceChildren(label);

    const icon = document.createElement('ion-icon');
    icon.setAttribute('name', 'arrow-down-circle-outline');
    icon.classList.add('circle-outline-icon');
    filterDropdownBtn.appendChild(icon);

    selectedOption.style.fontWeight = 'bold';
    const syncExpanded = () => filterDropdownBtn.setAttribute('aria-expanded', String(filterDropdownContent.classList.contains('show')));
    new MutationObserver(syncExpanded).observe(filterDropdownContent, {attributes:true, attributeFilter:['class']});
    syncExpanded();
    productFiltring.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        filterDropdownContent.classList.remove('show');
        filterDropdownBtn.focus();
      }
    });

    // Handle the click event for the dropdown button
    let isDropdownClicked = false;

    productFiltring.addEventListener('click', () => {
      if (!isDropdownClicked) {
        productFiltring.style.borderColor = '#000';
      } else {
        productFiltring.style.borderColor = '';
      }
      isDropdownClicked = !isDropdownClicked;
    });

    window.addEventListener('click', (event) => {
      if (!event.target.matches('.dropbtn, .dropbtn *')) {
        productFiltring.style.borderColor = '';
        isDropdownClicked = false; // Reset the click state
      }
    });

    setupDropdown(filterDropdownContent, convertUrlWithMultipleQuery);
  }
}

filterProduct();

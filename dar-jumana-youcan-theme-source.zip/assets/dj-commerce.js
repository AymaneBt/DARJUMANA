/* Presentation only. Native Harmony/YouCan code owns variants, inventory, cart and checkout. */
(() => {
  function initCommerce(scope = document) {
    scope.querySelectorAll('[data-dj-gallery]').forEach(gallery => {
      if (gallery.dataset.djReady) return;
      gallery.dataset.djReady = 'true';
      const main = gallery.querySelector('.main-image');
      const mainButton = gallery.querySelector('[data-dj-zoom]');
      const thumbs = [...gallery.querySelectorAll('[data-dj-thumbnail]')];
      const dialog = gallery.querySelector('[data-dj-image-dialog]');
      const counter = gallery.querySelector('[data-dj-gallery-counter]');
      if (!main || !mainButton || !dialog) return;
      let index = 0;
      function select(next) {
        if (!thumbs.length) return;
        index = (next + thumbs.length) % thumbs.length;
        const image = thumbs[index].querySelector('img');
        main.src = image.src;
        thumbs.forEach((thumb, position) => thumb.setAttribute('aria-pressed', String(position === index)));
        if (counter) counter.textContent = `${index + 1} / ${thumbs.length}`;
      }
      thumbs.forEach((thumb, position) => thumb.addEventListener('click', () => select(position)));
      mainButton.addEventListener('keydown', event => {
        const rtl = getComputedStyle(gallery).direction === 'rtl';
        if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
          event.preventDefault();
          select(index + (event.key === (rtl ? 'ArrowLeft' : 'ArrowRight') ? 1 : -1));
        }
      });
      let touchX = null;
      mainButton.addEventListener('touchstart', event => { touchX = event.changedTouches[0].clientX; }, {passive: true});
      mainButton.addEventListener('touchend', event => {
        if (touchX === null) return;
        const delta = event.changedTouches[0].clientX - touchX;
        if (Math.abs(delta) > 45) {
          const rtl = getComputedStyle(gallery).direction === 'rtl';
          select(index + (delta > 0 ? (rtl ? 1 : -1) : (rtl ? -1 : 1)));
          // Ignore the click synthesized by this swipe.
          mainButton.dataset.swiped = 'true';
          setTimeout(() => delete mainButton.dataset.swiped, 400);
        }
        touchX = null;
      }, {passive: true});
      mainButton.addEventListener('click', () => {
        if (mainButton.dataset.swiped || !main.complete || !main.naturalWidth) return;
        const image = document.createElement('img');
        image.src = main.currentSrc || main.src;
        image.alt = main.alt;
        image.width = main.naturalWidth;
        image.height = main.naturalHeight;
        dialog.querySelector('[data-dj-zoom-media]').replaceChildren(image);
        if (typeof dialog.showModal === 'function') dialog.showModal();
      });
      gallery.querySelector('[data-dj-close-zoom]').addEventListener('click', () => dialog.close());
      dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
      // A native variant image change remains authoritative; update thumbnail state accordingly.
      new MutationObserver(() => {
        const matched = thumbs.findIndex(thumb => thumb.querySelector('img').src === main.src);
        if (matched >= 0) {
          index = matched;
          thumbs.forEach((thumb, position) => thumb.setAttribute('aria-pressed', String(position === index)));
          if (counter) counter.textContent = `${index + 1} / ${thumbs.length}`;
        }
      }).observe(main, {attributes:true, attributeFilter:['src']});
    });
    scope.querySelectorAll('.dj-commerce .yc-single-product').forEach(product => {
      if (product.dataset.djReady) return;
      product.dataset.djReady = 'true';
      const bar = product.querySelector('[data-dj-sticky]');
      const buy = product.querySelector('.add-to-cart-button, .express-checkout-button');
      if (!bar || !buy) return;
      product.querySelector('[data-dj-return-buy]').addEventListener('click', () => {
        product.querySelector('.dj-product-purchase').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth',block:'center'});
        buy.focus({preventScroll:true});
      });
      if ('IntersectionObserver' in window) {
        new IntersectionObserver(entries => {
          const entry = entries[0];
          // Show only after the purchase button has scrolled above the viewport.
          const show = !entry.isIntersecting && entry.boundingClientRect.top < 0;
          bar.hidden = !show;
          document.body.classList.toggle('dj-has-product-sticky', show);
        }, {threshold:0}).observe(buy);
      }
    });
    scope.querySelectorAll('.dj-commerce .dropbtn,.dj-commerce .dropdown-content li,.dj-commerce .yc-upload').forEach(control => {
      if (control.dataset.djKeyboard) return;
      control.dataset.djKeyboard = 'true';
      control.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); control.click(); }
        if (event.key === 'Escape') control.closest('.dropdown-input')?.querySelector('.dropdown-content')?.classList.remove('show');
      });
    });
    // Native variant controls retain their selectors and handlers; add keyboard activation.
    scope.querySelectorAll('.dj-commerce .yc-options-item,.dj-commerce .yc-image-options-item,.dj-commerce .color-item').forEach(control => {
      if (control.dataset.djKeyboard) return;
      control.dataset.djKeyboard = 'true';
      control.tabIndex = 0;
      control.setAttribute('role','button');
      control.setAttribute('aria-pressed',String(control.classList.contains('active')));
      control.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); control.click(); }
      });
      new MutationObserver(() => control.setAttribute('aria-pressed',String(control.classList.contains('active')))).observe(control,{attributes:true,attributeFilter:['class']});
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => initCommerce());
  else initCommerce();
})();

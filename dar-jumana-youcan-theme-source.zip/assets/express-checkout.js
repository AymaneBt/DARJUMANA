async function placeOrder(button) {
  const expressCheckoutForm = (button && button.closest('form')) || document.querySelector('#express-checkout-form');
  let fields = Object.fromEntries(new FormData(expressCheckoutForm));

  const isBundleForm = expressCheckoutForm?.id === 'bundle-express-checkout-form';
  const productVariantId = document.getElementById('variantId')?.value;
  const bundleId = document.querySelector('[data-bundle] input[type="checkbox"]:checked')?.value;

  if (isBundleForm && !bundleId) {
    return notify(ADD_TO_CART_EXPECTED_ERRORS.select_bundle, 'warning');
  }

  load('#loading__checkout');
  try {
    const quantity = document.getElementById('quantity')?.value || 1;
    const attachedImage = document.querySelector('#yc-upload-link')?.value;

    if (attachedImage) {
      fields = { ...fields, attachedImage };
    }

    const response = await youcanjs.checkout.placeExpressCheckoutOrder({
      quantity,
      fields,
      ...(isBundleForm ? { bundleId, isBundle: true } : { productVariantId }),
    });

    response
      .onSuccess((data, redirectToThankyouPage) => {
        redirectToThankyouPage();
      })
      .onValidationErr((err) => {
        const form = expressCheckoutForm;
        const formFields = Object.keys(err.meta.fields);

        if (!form || !formFields) return;

        formFields.forEach(field => {
          const fieldName = field.indexOf('extra_fields') > -1 ? field.replace('extra_fields.', 'extra_fields[') + ']' : field;

          const formField = form.querySelector(`[name="${fieldName}"]`);
          const errorEl = form.querySelector(`.validation-error[data-error="${fieldName}"]`);
          if (formField) {
            formField.classList.add('error');
          }

          if (errorEl) {
            errorEl.innerHTML = err.meta.fields[field][0];
          }

          formField.addEventListener('formField', () => {
            formField.classList.remove('error');
            errorEl.innerHTML = '';
          });
        });

        const formTop = form.getBoundingClientRect().top;

        if (!document.querySelector('#yc-sticky-checkout')) {
          window.scrollBy({ top: formTop - window.innerHeight / 3, behavior: 'smooth' });
        }
      })
      .onSkipShippingStep((data, redirectToShippingPage) => {
        redirectToShippingPage();
      })
      .onSkipPaymentStep((data, redirectToPaymentPage) => {
        redirectToPaymentPage();
      });
  } catch (e) {
    notify(e.message, 'error');
  } finally {
    stopLoad('#loading__checkout');
  }
}

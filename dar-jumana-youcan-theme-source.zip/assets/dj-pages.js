/* Present existing FAQ text as native disclosures without changing stored page content. */
(() => {
  document.querySelectorAll('[data-dj-faq]').forEach(page => {
    if (page.querySelector('details')) return;
    [...page.querySelectorAll('h3')].forEach(heading => {
      const details = document.createElement('details');
      const summary = document.createElement('summary');
      summary.textContent = heading.textContent;
      details.append(summary);
      let next = heading.nextSibling;
      while (next && !(next.nodeType === Node.ELEMENT_NODE && /^H[1-3]$/.test(next.tagName))) {
        const following = next.nextSibling;
        details.append(next);
        next = following;
      }
      heading.replaceWith(details);
    });
  });
})();
